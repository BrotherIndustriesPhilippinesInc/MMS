// function renderLineCountTable(data) {
//     if (!data || data.length === 0) {
//         $("#pivotTableBody").html("<tr><td>No data found.</td></tr>");
//         return;
//     }

//     // Table Head Body references
//     const tableHead = document.getElementById("pivotTable");
//     const tableBody = document.getElementById("pivotTableBody");

//     tableHead.innerHTML = "";
//     tableBody.innerHTML = "";

//     // Build Header Rows
//     const headerRow1 = document.createElement("tr");
//     const headerRow2 = document.createElement("tr");

//     headerRow1.innerHTML = `
//         <th rowspan="2">Manpower Classification</th>
//         <th rowspan="2">Skills</th>
//     `;

//     const sample = data[0];
//     const columns = Object.keys(sample).filter(c =>
//         c !== "Skill" && c !== "ManpowerClassification"
//     );

//     const days = {};

//     columns.forEach(col => {
//         let parts = col.split("_");
//         let day = parts[parts.length - 1];

//         if (!days[day]) days[day] = [];
//         days[day].push(col);
//     });

//     Object.keys(days).forEach(day => {
//         headerRow1.innerHTML += `
//             <th class="text-center">${day}</th>
//         `;
//         // headerRow2.innerHTML += `
//         //     <th>Actual MP</th>
           
//         // `;
//         //  <th>Ideal MP</th>
//     });

//     tableHead.appendChild(headerRow1);
//     // tableHead.appendChild(headerRow2);

//     // Build Data Rows
//     data.forEach(row => {
//         let tr = document.createElement("tr");

//         tr.innerHTML = `
//             <td>${row.ManpowerClassification}</td>
//             <td>${row.Skill}</td>
//         `;

//         Object.keys(days).forEach(day => {
//             // Actual & Ideal column names
//             let actualKey = Object.keys(row).find(k => k == day);
//             // let idealKey = Object.keys(row).find(k => k == `Ideal_${day}`);
//             // <td>${row[idealKey] ?? 0}</td>

//             tr.innerHTML += `
//                 <td>${row[actualKey] ?? 0}</td>
                
//             `;
//         });

//         tableBody.appendChild(tr);
//     });

//     buildDropdownFilters(data);
// }


function renderLineCountTable(data) {
    if (!data || data.length === 0) {
        $("#pivotTableBody").html("<tr><td>No data found.</td></tr>");
        return;
    }

    // Table Head + Body references
    const tableHead = document.getElementById("pivotTable");
    const tableBody = document.getElementById("pivotTableBody");

    tableHead.innerHTML = "";
    tableBody.innerHTML = "";

    // Build Header Rows
    const headerRow1 = document.createElement("tr");

    headerRow1.innerHTML = `
        <th rowspan="2">Manpower Classification</th>
        <th rowspan="2">Skills</th>
    `;

    const sample = data[0];
    const columns = Object.keys(sample).filter(c =>
        c !== "Skill" && c !== "ManpowerClassification"
    );

    const days = {};

    columns.forEach(col => {
        let parts = col.split("_");
        let day = parts[parts.length - 1];

        if (!days[day]) days[day] = [];
        days[day].push(col);
    });

    Object.keys(days).forEach(day => {
        headerRow1.innerHTML += `<th class="text-center">${day}</th>`;
    });

    tableHead.appendChild(headerRow1);

    // Build Data Rows
    const totals = {}; 
    Object.keys(days).forEach(day => totals[day] = 0);

    data.forEach(row => {
        let tr = document.createElement("tr");

        tr.innerHTML = `
            <td>${row.ManpowerClassification}</td>
            <td>${row.Skill}</td>
        `;

     Object.keys(days).forEach(day => {
        let actualKey = Object.keys(row).find(k => k == day);
        let val = row[actualKey] ?? 0;
        totals[day] += Number(val);
        const dateObj = new Date(day);
        const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        const dayName = dayNames[dateObj.getDay()];

        // let style = '';
        // if (dayName === 'Sun') {
        //     style = 'background-color: #ff0000;font-weight:bold;';
        // } else if (dayName === 'Sat') {
        //     style = 'background-color:#6c757d;';
        // style="${style}"
        // }

        tr.innerHTML += `
            <td >
                ${val}
            </td>
        `;
    });


        tableBody.appendChild(tr);
    });


    // Build Total Row
    let totalRow = document.createElement("tr");
    totalRow.innerHTML = `<td colspan="2" class="text-end fw-bold" style="">Total</td>`;

    Object.keys(days).forEach(day => {
        totalRow.innerHTML += `<td class="fw-bold" style="color: blue;">${totals[day]}</td>`;
    });



    tableBody.appendChild(totalRow);

    buildDropdownFilters(data);
}


// BUILD FILTER DROPDOWNS
function buildDropdownFilters(data) {
    const mpSet = new Set();
    const skillSet = new Set();

    data.forEach(row => {
        mpSet.add(row.ManpowerClassification);
        skillSet.add(row.Skill);
    });

    $("#mpClassFilter").empty().append(`<option value="">All</option>`);
    $("#skillFilter").empty().append(`<option value="">All</option>`);

    mpSet.forEach(val => {
        $("#mpClassFilter").append(`<option value="${val}">${val}</option>`);
    });

    skillSet.forEach(val => {
        $("#skillFilter").append(`<option value="${val}">${val}</option>`);
    });

    $("#mpClassFilter, #skillFilter").select2({
        width: "100%",
        theme: "bootstrap-5",
        placeholder: "Select option",
        allowClear: true
    });
}



// FILTER TABLE
function filterPivotTable() {
    const mpFilter = $("#mpClassFilter").val();
    const skillFilter = $("#skillFilter").val();

    $("#pivotTableBody tr").each(function () {
        const mp = $(this).find("td:nth-child(1)").text().trim();
        const skill = $(this).find("td:nth-child(2)").text().trim();

        let show = true;

        if (mpFilter && mp !== mpFilter) show = false;
        if (skillFilter && skill !== skillFilter) show = false;

        $(this).toggle(show);
    });
}

// Trigger filter event
$("#mpClassFilter, #skillFilter").on("change", function () {
    filterPivotTable();
});



// AJAX BUTTON

$("#insertPivotBtn").click(function() {
    const month_Val = $('#monthInput').val();
    const year_Val = $('#yearInput').val();
    const shift_Val = $('#shiftInput').val();
    const costCode_Val = $('#costCodeInput').val();

    $.ajax({
        url: 'Controller/line_class.php?action=get_lineCount',
        method: 'POST',
        data: {
            month: month_Val,
            year: year_Val,
            shift: shift_Val,
            costCode: costCode_Val,
        },
        dataType: 'json',
        success: function(res) {
            if (res.success) {
                if (res.data1 && res.data1.length > 0) {
                    renderLineCountTable(res.data1);
                } else {
                    $('#pivotTableBody').html('<tr><td colspan="32">No data found.</td></tr>');
                }
            } else {
                Swal.fire('Error', 'Attendance Data Error: ' + res.error, 'error');
            }
        },
        error: function(xhr, status, error) {
            Swal.fire('Error', 'AJAX Error: ' + status + ' (' + error + ')', 'error');
        }
    });
});
