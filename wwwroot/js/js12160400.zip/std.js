$(document).ready(function() {

    function buildAttendanceTable(data) {
        const metricLabels = {
            'Register MP': 'Register MP',
            'Actual': 'Present (Actual)',
            'Lacking': 'Lacking',
            'Absent': 'Absent',
            'MLCount': 'ML Count',
            
            'NWCount': 'NW Count (No Work)',
            'AbsentRate': 'Absent Rate'
        };

        let headerHTML = '<th>Metric / Day</th>';
        let bodyHTML = '';

        // data.forEach(dayData => {
        //     headerHTML += `<th>${dayData.MonthDay}</th>`; 
        // });
        data.forEach(dayData => {
            // Expect MonthDay = day number (1–31)
            const day = parseInt(dayData.MonthDay, 10);

            // Use selected month/year inputs
            const month = parseInt($('#monthInput').val(), 10) - 1; // JS months are 0-based
            const year = parseInt($('#yearInput').val(), 10);

            const dateObj = new Date(year, month, day);

            const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            const dayName = dayNames[dateObj.getDay()];

            headerHTML += `<th>${dayName}<br>${day}</th>`;
        });

        $('#headerRow').html(headerHTML);

        for (const [key, label] of Object.entries(metricLabels)) {
            let row = `<tr><td>${label}</td>`;

            data.forEach(dayData => {
                let value = dayData[key]; 
                let cellStyle = '';

                if (key === 'AbsentRate') {
                    value = parseFloat(value).toFixed(2) + '%';
                } else if (value === null || value === undefined) {
                    value = '0'; 
                } else if ($.isNumeric(value)) {
                    const numericValue = parseInt(value, 10);
                    value = numericValue;

                    if (key === 'Lacking') {
                        if (numericValue > 0) {
                            cellStyle = 'style="color: red; font-weight: bold;"'; 
                        } else if (numericValue < 0) {
                            cellStyle = 'style="color: blue; font-weight: bold;"'; 
                        }
                    }
                }

                row += `<td ${cellStyle}>${value}</td>`;
            });

            row += '</tr>';
            bodyHTML += row;
        }

        // Close SweetAlert loading after table body is ready
        $('#tableBody').html(bodyHTML);
        Swal.close();
    }

    $('#insertPivotBtn').on('click', function() {
        const dateVal = $('#dateInput').val();
        const monthVal = $('#monthInput').val();
        const yearVal = $('#yearInput').val();
        const shiftVal = $('#shiftInput').val();
        const costCodeVal = $('#costCodeInput').val();

        if (!monthVal || !yearVal || !shiftVal || !costCodeVal) {
            Swal.fire('Error', 'Please fill in all required date, shift, and cost code fields.', 'error');
            return;
        }

        const $btn = $(this);
        $btn.prop('disabled', true).text('Processing...');
        $('#status').hide().html('');
        $('#pivotTable').html('');
        $('#summaryTable').html('');
        $('#headerRow').html('<th>Metric</th>');
        $('#tableBody').html('');

        // Show SweetAlert loading for tbody
        Swal.fire({
            title: 'Processing attendance...',
            html: 'Please wait while the table is being generated.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        $.ajax({
            url: 'Controller/std_class.php?action=get_attendancecount',
            method: 'POST',
            data: {
                month: monthVal,
                year: yearVal,
                shift: shiftVal,
                costCode: costCodeVal,
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    if (response.data && response.data.length > 0) {
                        buildAttendanceTable(response.data);
                        Swal.fire('Success', 'Attendance metrics successfully retrieved.', 'success');
                    } else {
                        $('#tableBody').html('<tr><td colspan="32">No daily attendance data found.</td></tr>');
                        Swal.close();
                    }
                } else {
                    Swal.fire('Error', 'Attendance Data Error: ' + response.error, 'error');
                    $('#status').show().html('<div class="alert alert-danger">Error fetching attendance data: ' + response.error + '</div>');
                }
            },
            error: function(xhr, status, error) {
                Swal.fire('Error', 'An AJAX error occurred while fetching attendance data.', 'error');
                $('#status').show().html('<div class="alert alert-danger">AJAX Error: ' + status + ' (' + error + ')</div>');
            },
            complete: function() {
                $btn.prop('disabled', false).text('Load');
            }
        });
    });

    // Initialize DataTable
    if ($.fn.DataTable.isDataTable('#attendanceTable')) {
        $('#attendanceTable').DataTable().destroy();
    }

});
